# Первое задание
immutable_var = ([1 , 2 , 3 , 4], True , 'Ложь')
print(immutable_var)
# Второе задание
immutable_var = ([1 , 2 , 3 , 4], True , 'Ложь')
print(immutable_var[0])
immutable_var[0] = 'В кортеже можно либо  сложить строки, либо умножить менять их нельзя.'
# Третье задание
mutable_list = [1, 2, 'a', 'b', 'Modified']
print(mutable_list[0])
mutable_list[0] = 'Один'
print(mutable_list)
mutable_list.append('два')
print(mutable_list)
mutable_list.remove(2)
print(mutable_list)
mutable_list.extend('i,m всё понял')
print(mutable_list)


